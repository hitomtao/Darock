
REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,parent_id,description,content,rel_type,rel_id,position,is_deleted,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,categories_content_type,categories_silo_keywords) VALUES('1','2015-01-27 10:43:26','2015-01-27 10:42:56','2','2','category','Category 1','0','','','content','2','0','0','','0','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,parent_id,description,content,rel_type,rel_id,position,is_deleted,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,categories_content_type,categories_silo_keywords) VALUES('2','2015-01-27 10:43:48','2015-01-27 10:43:48','2','2','category','Category 2','0','','','content','2','0','0','','0','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,parent_id,description,content,rel_type,rel_id,position,is_deleted,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,categories_content_type,categories_silo_keywords) VALUES('3','2015-01-27 11:56:43','2015-01-27 11:56:43','2','2','category','Digital Cameras','0','','','content','5','0','0','','0','','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('1','2','content','4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('2','1','content','3'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('1','2015-01-26 17:11:20','2015-01-26 17:11:20','','','','page','','','Home','0','','','','','','','1','1','0','0','0','','','','static','','','','','index.php','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('2','2015-01-27 12:21:38','2015-01-27 10:39:12','','2','1','page','blog','','Blog','0','','','','','','','1','0','0','0','0','','0','','dynamic','','','','','layouts__blog.php','','','default','329c4c203856a933ff5dbd8b49f76a89dbe9f04b','2015-01-27 12:21:38'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('3','2015-01-27 12:21:38','2015-01-27 10:40:35','','2','1','post','the-rock','','The Rock','2','','','','','
            <module class=" module module-pictures " data-mw-title="Picture Gallery" id="module-pictures-editor_tools1046843207" data-type="pictures" data-template="simple" rel="content"></module><div class="edit element" field="content_body" rel="content">
              <div class="element">
                <p align="justify" class=" element">This text is set by default and is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative, Make Web.</p>
              </div>
            </div>
          ','','1','0','0','0','0','','0','','post','','','','','inherit','','','','329c4c203856a933ff5dbd8b49f76a89dbe9f04b','2015-01-27 10:40:35'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('4','2015-01-27 11:15:59','2015-01-27 10:54:15','','2','2','post','wild-animals','','Wild Animals','2','','','','','
            <module class="module module module-pictures " data-mw-title="Picture Gallery" id="module-pictures-editor_tools1046843207" data-type="pictures" data-template="simple" rel="content"></module><div class="edit element" field="content_body" rel="content" id="row_1422355454597">
              <div class="element" id="row_1422355454326">
                <p align="justify" class="element" id="row_1422355454224">This text is set by default and is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative, Make Web.</p>
              </div>
            </div>
          ','','1','0','0','0','0','','0','','post','','','','','inherit','','','','0f19e12be3c011a2569385943d7d371bd50b5083','2015-01-27 10:54:15'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('5','2015-01-27 11:56:17','2015-01-27 11:17:12','','2','2','page','shop','','Shop','0','','','','','','','1','0','0','1','0','','0','','dynamic','','','','','layouts__shop.php','','','default','0f19e12be3c011a2569385943d7d371bd50b5083','2015-01-27 11:56:17'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('6','2015-01-27 12:09:57','2015-01-27 11:54:29','','2','2','product','digital-camera','','Digital Camera','5','','','','','','
                 
                  <div class="edit element" field="content" rel="post"><p class="element" id="row_1422360553099">This text is set by default and it is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative &amp; <strong style="font-weight: 600">Make Web</strong>.</p></div>
                ','1','0','0','0','0','','0','','product','','','','','inherit','','','','0f19e12be3c011a2569385943d7d371bd50b5083','2015-01-27 11:54:29'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('7','2015-01-27 11:56:17','2015-01-27 11:56:17','','2','2','product','climb-with-my-shoes','','Climb With My Shoes','5','','','','','

        <div class="mw-row shop-product-row" style="height: auto;" id="row_1422359723002">
          <div class="mw-col" style="width: 65%; height: auto;">
            <div class="mw-col-container">
              <module class="module module module-pictures" data-mw-title="Picture Gallery" id="module-pictures-editor_tools1126839982" rel="content" template="simple" data-type="pictures"></module>
</div>
          </div>
          <div class="mw-col" style="width: 35%; height: auto;">
            <div class="mw-col-container">
              <div class="product-description element" id="row_1422359723629">
                 <div class="edit element" field="content_body" rel="post" id="row_1422359723089">
                <h2 class=" element" id="row_1422359723073">Product inner page</h2>
                  <p class="element">This text is set by default and it is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative &amp; <strong style="font-weight: 600">Make Web</strong>.</p>
                </div>
                <module class="module module module-shop-cart-add " data-mw-title="Add to cart" id="module-shop-cart-add-editor_tools1706281220" rel="post" data-type="shop/cart_add"></module>
</div>
            </div>
          </div>
        </div>
      ','','1','0','0','0','0','','0','','product','','','','','inherit','','','','0f19e12be3c011a2569385943d7d371bd50b5083','2015-01-27 11:56:17'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('8','2015-01-27 12:09:56','2015-01-27 12:09:56','','2','2','page','gallery','','Gallery','0','','','','','','','1','0','0','0','0','','0','','static','','','','','layouts__gallery.php','','','default','0f19e12be3c011a2569385943d7d371bd50b5083','2015-01-27 12:09:56'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('9','2015-01-27 12:11:24','2015-01-27 12:11:24','','2','2','page','about','','About ','0','','','','','','','1','0','0','0','0','','0','','static','','','','','text_page.php','','','default','0f19e12be3c011a2569385943d7d371bd50b5083','2015-01-27 12:11:24'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('10','2015-01-27 12:13:12','2015-01-27 12:13:12','','2','2','page','contact-us','','Contact Us','0','','','','','','','1','0','0','0','0','','0','','static','','','','','contacts.php','','','default','0f19e12be3c011a2569385943d7d371bd50b5083','2015-01-27 12:13:12'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('1','2015-01-27 11:54:29','2015-01-27 11:54:29','2','2','6','qty','nolimit','0f19e12be3c011a2569385943d7d371bd50b5083','content','6'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('2','2015-01-27 11:54:29','2015-01-27 11:54:29','2','2','6','sku','','0f19e12be3c011a2569385943d7d371bd50b5083','content','6'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('3','2015-01-27 11:54:29','2015-01-27 11:54:29','2','2','6','shipping_weight','','0f19e12be3c011a2569385943d7d371bd50b5083','content','6'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('4','2015-01-27 11:54:29','2015-01-27 11:54:29','2','2','6','shipping_width','','0f19e12be3c011a2569385943d7d371bd50b5083','content','6'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('5','2015-01-27 11:54:29','2015-01-27 11:54:29','2','2','6','shipping_height','','0f19e12be3c011a2569385943d7d371bd50b5083','content','6'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('6','2015-01-27 11:54:29','2015-01-27 11:54:29','2','2','6','shipping_depth','','0f19e12be3c011a2569385943d7d371bd50b5083','content','6'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('7','2015-01-27 11:54:29','2015-01-27 11:54:29','2','2','6','additional_shipping_cost','','0f19e12be3c011a2569385943d7d371bd50b5083','content','6'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('8','2015-01-27 11:56:17','2015-01-27 11:56:17','2','2','7','qty','nolimit','0f19e12be3c011a2569385943d7d371bd50b5083','content','7'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('9','2015-01-27 11:56:17','2015-01-27 11:56:17','2','2','7','sku','','0f19e12be3c011a2569385943d7d371bd50b5083','content','7'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('10','2015-01-27 11:56:17','2015-01-27 11:56:17','2','2','7','shipping_weight','','0f19e12be3c011a2569385943d7d371bd50b5083','content','7'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('11','2015-01-27 11:56:17','2015-01-27 11:56:17','2','2','7','shipping_width','','0f19e12be3c011a2569385943d7d371bd50b5083','content','7'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('12','2015-01-27 11:56:17','2015-01-27 11:56:17','2','2','7','shipping_height','','0f19e12be3c011a2569385943d7d371bd50b5083','content','7'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('13','2015-01-27 11:56:17','2015-01-27 11:56:17','2','2','7','shipping_depth','','0f19e12be3c011a2569385943d7d371bd50b5083','content','7'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('14','2015-01-27 11:56:17','2015-01-27 11:56:17','2','2','7','additional_shipping_cost','','0f19e12be3c011a2569385943d7d371bd50b5083','content','7'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('1','2015-01-27 11:59:04','2015-01-27 11:59:04','2','2','content','3','post-social-bar','
            <div class="blog-socials-bar element" style="width: 320px;">
              <div class="mw-ui-row-nodrop element">
                <div class="mw-ui-col" style="width: 60px;">
                  <div class="mw-ui-col-container">
                    <module class=" module module-facebook-like " id="module-facebook-like-the-rock4105779044" show-faces="false" layout="box_count" data-type="facebook_like"></module>
                  </div>
                </div>
                <div class="mw-ui-col">
                  <div class="mw-ui-col-container" style="padding-top: 25px;">
                    
                    
</div>
                </div>

                <div class="mw-ui-col">
                  <div class="mw-ui-col-container" style="padding-top: 25px;">
                    <a data-pin-href="http://www.pinterest.com/pin/create/button/" data-pin-log="button_pinit_bookmarklet" class="PIN_1422359914258_pin_it_button_28 PIN_1422359914258_pin_it_button_en_28_gray PIN_1422359914258_pin_it_button_inline_28 PIN_1422359914258_pin_it_none_28" data-pin-config="none"><span class="PIN_1422359914258_hidden" id="PIN_1422359914258_pin_count_0"><i></i></span></a>
                    
</div>
                </div>
              </div>
            </div>
          '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('2','2015-01-27 12:09:57','2015-01-27 12:09:57','2','2','content','6','content_body','
                 
                  <div class="edit element" field="content" rel="post"><p class="element" id="row_1422360553099">This text is set by default and it is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative &amp; <strong style="font-weight: 600">Make Web</strong>.</p></div>
                '); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('1','content','5','','price','price','price','2015-01-27 11:16:25','2015-01-27 11:16:25','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('2','content','6','','price','price','price','2015-01-27 11:52:54','2015-01-27 11:52:07','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('3','content','7','','price','price','price','2015-01-27 11:55:47','2015-01-27 11:55:17','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('4','module','contact-form','0','name','Name','name','2015-01-27 12:12:58','2015-01-27 12:12:58','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('5','module','contact-form','1','email','Email','email','2015-01-27 12:12:58','2015-01-27 12:12:58','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('6','module','contact-form','2','message','Message','message','2015-01-27 12:12:58','2015-01-27 12:12:58','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','','1','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('1','1','0','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('2','2','3580','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('3','3','150','0'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('1','2015-01-27 10:40:17','2015-01-27 10:40:17','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','3','picture','9999999','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/2012_1003.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('2','2015-01-27 10:40:18','2015-01-27 10:40:18','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','3','picture','9999999','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/2012_1037.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('3','2015-01-27 10:40:20','2015-01-27 10:40:20','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','3','picture','9999999','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/cover_7.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('5','2015-01-27 10:45:05','2015-01-27 10:45:05','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','4','picture','2','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/9622657288_07af56dc29_c.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('6','2015-01-27 10:45:08','2015-01-27 10:45:08','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','4','picture','1','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/9756849575_1cc190666e_b.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('7','2015-01-27 10:45:12','2015-01-27 10:45:12','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','4','picture','0','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/10552010753_d67134c914_h.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('8','2015-01-27 11:53:56','2015-01-27 11:53:56','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','6','picture','2','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/6028849961_c123999955_z.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('9','2015-01-27 11:53:57','2015-01-27 11:53:57','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','6','picture','0','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/amateur_photography.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('10','2015-01-27 11:53:58','2015-01-27 11:53:58','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','6','picture','1','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/aparat.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('11','2015-01-27 11:53:59','2015-01-27 11:53:59','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','6','picture','3','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/photography_beginner.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('12','2015-01-27 11:54:00','2015-01-27 11:54:00','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','6','picture','4','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/photography_business_management_tips_1_2_800x477.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('13','2015-01-27 11:55:54','2015-01-27 11:55:54','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','7','picture','9999999','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/439158498_359.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('14','2015-01-27 11:55:55','2015-01-27 11:55:55','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','7','picture','9999999','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/439158599_860.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('15','2015-01-27 11:55:56','2015-01-27 11:55:56','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','7','picture','9999999','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/hanagal_professional_women_s_mountain_hiking.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('16','2015-01-27 12:10:33','2015-01-27 12:10:33','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','8','picture','9999999','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/9997862744_c050066a2a_h.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('17','2015-01-27 12:10:34','2015-01-27 12:10:34','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','8','picture','9999999','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/10295747216_35470c8cb7_k_min.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('18','2015-01-27 12:10:36','2015-01-27 12:10:36','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','8','picture','9999999','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/13982700002_f0e697fe2f_b.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('19','2015-01-27 12:10:39','2015-01-27 12:10:39','2','2','0f19e12be3c011a2569385943d7d371bd50b5083','content','8','picture','9999999','','','','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/14473081211_663d96ef47_b.jpg'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('1','header_menu','menu','','','','','2015-01-26 17:11:20','2015-01-26 17:11:20','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('2','','menu_item','1','1','','0','2015-01-26 17:11:20','2015-01-26 17:11:20','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('3','footer_menu','menu','','','','','2015-01-26 17:11:20','2015-01-26 17:11:20','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('6','','menu_item','1','5','','1','2015-01-27 11:58:59','2015-01-27 11:58:59','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('5','','menu_item','1','2','','2','2015-01-27 10:41:02','2015-01-27 10:41:02','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('7','','menu_item','1','8','','6','2015-01-27 12:09:56','2015-01-27 12:09:56','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('8','','menu_item','3','8','','999999','2015-01-27 12:09:56','2015-01-27 12:09:56','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('9','','menu_item','1','9','','5','2015-01-27 12:11:42','2015-01-27 12:11:42','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('10','','menu_item','5','','1','3','2015-01-27 12:12:08','2015-01-27 12:12:08','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('11','','menu_item','5','','2','4','2015-01-27 12:12:14','2015-01-27 12:12:14','','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('1','2015-01-26 17:11:20','2015-01-26 17:11:20','current_template','darock','','','','template','','','','','','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('2','2015-01-26 17:11:20','2015-01-26 17:11:20','website_title','Microweber','','','','website','','','','','','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('3','2015-01-26 17:11:20','2015-01-26 17:11:20','enable_comments','y','','','','comments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('4','2015-01-27 10:42:05','2015-01-27 10:42:05','size','auto','','','','logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('5','2015-01-27 10:42:05','2015-01-27 10:42:05','logoimage','{SITE_URL}userfiles/media/darock-content-microweber-com/uploaded/LOGO_ORG.png','','','','logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('6','2015-01-27 11:55:03','2015-01-27 11:55:03','data-template','single.php','','','','module-shop-products-shop4280785763','','','','','shop/products',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('7','2015-01-27 11:59:51','2015-01-27 11:59:51','data-content-id','2','','','','blog_sidebar_categories','','','','','categories',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('8','2015-01-27 12:13:36','2015-01-27 12:13:36','facebook_enabled','y','','','','module-social-links-contact-us4258172457','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('9','2015-01-27 12:13:37','2015-01-27 12:13:37','twitter_enabled','y','','','','module-social-links-contact-us4258172457','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('10','2015-01-27 12:13:38','2015-01-27 12:13:38','googleplus_enabled','y','','','','module-social-links-contact-us4258172457','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('11','2015-01-27 12:13:42','2015-01-27 12:13:42','pinterest_enabled','y','','','','module-social-links-contact-us4258172457','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('12','2015-01-27 12:13:43','2015-01-27 12:13:43','youtube_enabled','y','','','','module-social-links-contact-us4258172457','','','','','social_links',''); /* MW_QUERY_SEPERATOR */





